package com.example.myapplication;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;

import com.alibaba.android.vlayout.LayoutHelper;
import com.alibaba.android.vlayout.layout.LinearLayoutHelper;

public class FooterRefreshAdapter extends BaseAdapter<Object> {

    public interface FooterListener {
        void onLoadMore();
    }

    private final int viewtype = hashCode();
    private State mState = State.NoMore;
    private boolean hasMore = false;
    private FooterRefreshHolder mHolder;
    private FooterListener mListener;

    public FooterRefreshAdapter(@NonNull Context context) {
        super(context);
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
        setState(hasMore ? State.Complete : State.NoMore);
    }

    public void setFooterListener(FooterListener listener) {
        mListener = listener;
    }

    public void setState(State state) {
        mState = state;
        if (mHolder != null) mHolder.refresh();
    }

    public void setState(State state, boolean hasMore) {
        this.hasMore = hasMore;
        setState(state);
    }

    public void complete(boolean hasMore) {
        setState(State.Complete, hasMore);
    }

    public void error() {
        setState(State.Error);
    }

    @Override
    public LayoutHelper onCreateLayoutHelper() {
        return new LinearLayoutHelper();
    }

    @Override
    public int getItemViewType(int position) {
        return viewtype;
    }

    @Override
    public void onViewAttachedToWindow(@NonNull BaseAdapterHolder holder) {
        super.onViewAttachedToWindow(holder);
        mHolder = (FooterRefreshHolder) holder;
        ((FooterRefreshHolder) holder).refresh();
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull BaseAdapterHolder holder) {
        super.onViewDetachedFromWindow(holder);
        mHolder = null;
    }

    @NonNull
    @Override
    public BaseAdapterHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new FooterRefreshHolder(mLayoutInflater.inflate(R.layout.item_refresh_footer, parent, false));
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    @Override
    public void onBindViewHolder(@NonNull BaseAdapterHolder holder, int position) {

    }

    private class FooterRefreshHolder extends BaseAdapter<Object>.BaseAdapterHolder {

        private final FooterRefreshContainer mFooterContainer;
        private final ViewGroup mNoMoreLayout;
        private final ViewGroup mLoadingLayout;
        private final ViewGroup mErrorLayout;
        private final ViewGroup mCompleteLayout;

        public FooterRefreshHolder(@NonNull View itemView) {
            super(itemView);
            mFooterContainer = (FooterRefreshContainer) itemView;
            mFooterContainer.setListener(mContainerListener);
            mNoMoreLayout = itemView.findViewById(R.id.no_more_layout);
            mLoadingLayout = itemView.findViewById(R.id.loading_layout);
            mErrorLayout = itemView.findViewById(R.id.retry_layout);
            mCompleteLayout = itemView.findViewById(R.id.complete_layout);

            mErrorLayout.setOnClickListener((view) -> {
                setState(State.Loading);
                noticeLoadMore();
            });
        }

        private void setVisibility(int visibility, View... views) {
            for (View view : views) {
                view.setVisibility(visibility);
            }
        }

        public void refresh() {
            setVisibility(View.GONE, mNoMoreLayout, mLoadingLayout, mErrorLayout, mCompleteLayout);
            switch (mState) {
                case NoMore:
                    mNoMoreLayout.setVisibility(View.VISIBLE);
                    break;
                case Error:
                    mErrorLayout.setVisibility(View.VISIBLE);
                    break;
                case Loading:
                    mLoadingLayout.setVisibility(View.VISIBLE);
                    break;
                case Complete:
                    mCompleteLayout.setVisibility(View.VISIBLE);
                    break;
            }
        }

        private void noticeLoadMore() {
            FooterListener listener = mListener;
            if (listener != null) listener.onLoadMore();
        }

        private final FooterRefreshContainer.FooterContainerAttachedListener mContainerListener = () -> {
            if (!hasMore || mState == State.Loading || mState == State.Error) return;
            setState(State.Loading);
            noticeLoadMore();
        };
    }

    public enum State {
        NoMore,
        Loading,
        Error,
        Complete
    }
}
