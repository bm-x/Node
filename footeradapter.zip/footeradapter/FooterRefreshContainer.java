package com.example.myapplication;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class FooterRefreshContainer extends FrameLayout {

    interface FooterContainerAttachedListener {
        void onAttached();
    }

    private boolean overflowMode;

    public FooterRefreshContainer(@NonNull Context context) {
        super(context);
    }

    public FooterRefreshContainer(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public FooterRefreshContainer(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private FooterContainerAttachedListener mListener;

    public void setListener(FooterContainerAttachedListener listener) {
        mListener = listener;
    }

    public void setOverflowMode(boolean overflowMode) {
        this.overflowMode = overflowMode;
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        if (mListener == null) return;

        final int height = getHeight();

        if (!overflowMode || top >= height) {
            removeCallbacks(runnable);
            post(runnable);
        }
    }

    private final Runnable runnable = () -> {
        final FooterContainerAttachedListener listener = mListener;
        if (listener == null) return;
        listener.onAttached();
    };

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Log.i("clyde", "onSize change");
    }
}
